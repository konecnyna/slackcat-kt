package com.slackcat.chat.engine.cli

import com.slackcat.chat.models.ChatUser

object CliMockData {
    val defaultCliUser = ChatUser(userId = "42069_nice")
}
