package com.slackcat.common

data class RichTextMessage(val text: String)
