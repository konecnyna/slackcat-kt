package com.slackcat.app

enum class BigHipsChannels(val channelId: String) {
    SlackcatTesting(channelId = "C07V1626TC4")
}