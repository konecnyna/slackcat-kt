package com.slackcat.plugins

plugins {
    id("com.slackcat.plugins.base-internal")
}
