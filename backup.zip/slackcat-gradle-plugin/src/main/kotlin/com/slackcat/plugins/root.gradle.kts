package com.slackcat.plugins

plugins {
    id("com.slackcat.plugins.ktlint")
    id("com.slackcat.plugins.dependency-analysis")
}
