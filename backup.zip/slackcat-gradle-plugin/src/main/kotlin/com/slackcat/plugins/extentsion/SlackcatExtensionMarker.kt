package com.slackcat.plugins.extentsion

@DslMarker
annotation class SlackcatExtensionMarker
